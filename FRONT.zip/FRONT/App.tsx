
import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Landing from './pages/Landing';
import UserRegister from './pages/UserRegister';
import CompanyRegister from './pages/CompanyRegister';
import Dashboard from './pages/Dashboard';
import Opportunities from './pages/Opportunities';
import JobDetail from './pages/JobDetail';
import Applications from './pages/Applications';
import CompanyDashboard from './pages/CompanyDashboard';
import AboutUs from './pages/AboutUs';

const App: React.FC = () => {
  return (
    <Router>
      <div className="min-h-screen bg-slate-50 font-cairo" dir="rtl">
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/about" element={<AboutUs />} />
          <Route path="/register/user" element={<UserRegister />} />
          <Route path="/register/company" element={<CompanyRegister />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/dashboard/opportunities" element={<Opportunities />} />
          <Route path="/dashboard/opportunities/:id" element={<JobDetail />} />
          <Route path="/dashboard/applications" element={<Applications />} />
          <Route path="/company/dashboard" element={<CompanyDashboard />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
