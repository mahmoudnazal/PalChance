
import { Job, Notification } from './types';

export const palestinianJobs: Job[] = [
  {
    id: 1,
    title: "مهندس برمجيات Full Stack",
    company: "شركة تكنولوجيا حديثة",
    location: "رام الله",
    salary: "6000-9000 شيكل",
    type: "Full Time",
    match: 92,
    skills: ["React.js", "Node.js", "PostgreSQL", "Tailwind CSS", "TypeScript"],
    remote: "جزئياً عن بعد",
    description: "نحن نبحث عن مطور Full Stack موهوب للعمل على مشاريع ويب حديثة باستخدام أحدث التقنيات. ستشارك في تطوير منصات شاملة تخدم آلاف المستخدمين محلياً وعالمياً."
  },
  {
    id: 2,
    title: "مطور Frontend React",
    company: "شركة ناشئة تقنية",
    location: "بيت لحم", 
    salary: "5000-7500 شيكل",
    type: "Full Time",
    match: 87,
    skills: ["React", "Next.js", "TypeScript", "Tailwind", "Framer Motion"],
    remote: "حضوري",
    description: "انضم إلى فريقنا الديناميكي في بيت لحم لبناء واجهات مستخدم مذهلة وسريعة الاستجابة. نركز على تجربة المستخدم والأداء العالي."
  },
  {
    id: 3,
    title: "محلل بيانات Python",
    company: "شركة مالية كبرى",
    location: "القدس",
    salary: "7000-10000 شيكل",
    type: "Full Time",
    match: 91,
    skills: ["Python", "Pandas", "SQL", "Power BI", "Machine Learning"],
    remote: "هجين",
    description: "هل لديك شغف بالأرقام؟ نبحث عن محلل بيانات لاستخراج الرؤى من مجموعات البيانات الكبيرة وتحويلها إلى قرارات تجارية ذكية."
  },
  {
    id: 4,
    title: "مصمم UX/UI متقدم",
    company: "وكالة إعلانات",
    location: "نابلس",
    salary: "4500-6500 شيكل",
    type: "Full Time",
    match: 85,
    skills: ["Figma", "Adobe XD", "Prototyping", "User Research"],
    remote: "حضوري",
    description: "كن جزءاً من وكالة إبداعية في نابلس. ستقوم بتصميم واجهات تطبيقات الويب والهواتف الذكية مع التركيز على سهولة الاستخدام والجمالية."
  },
  {
    id: 5,
    title: "مدير تسويق رقمي",
    company: "متجر إلكتروني",
    location: "غزة",
    salary: "5500-8000 شيكل", 
    type: "Full Time",
    match: 88,
    skills: ["Google Ads", "Facebook Ads", "SEO", "Analytics"],
    remote: "عن بعد بالكامل",
    description: "ساعدنا في تنمية تجارتنا الإلكترونية في غزة وخارجها. ستقوم بإدارة الحملات الإعلانية وتحسين محركات البحث لزيادة المبيعات."
  },
  {
    id: 6,
    title: "مسؤول شبكات وأمن",
    company: "مزود خدمة إنترنت",
    location: "الخليل",
    salary: "6500-8500 شيكل",
    type: "Full Time",
    match: 82,
    skills: ["Cisco", "Firewalls", "Linux", "Network Security"],
    remote: "حضوري",
    description: "نبحث عن خبير في أمن الشبكات لحماية بنيتنا التحتية وضمان استمرارية الخدمة لعملائنا في منطقة الخليل."
  },
  {
    id: 7,
    title: "كاتب محتوى إبداعي",
    company: "منصة إخبارية",
    location: "جنين",
    salary: "3500-5000 شيكل",
    type: "Part Time",
    match: 79,
    skills: ["Arabic Writing", "Storytelling", "SEO Writing", "Content Strategy"],
    remote: "عن بعد",
    description: "هل تملك قلماً مبدعاً؟ نحن نبحث عن كتاب محتوى لإثراء منصتنا بمقالات وقصص تهم المجتمع الفلسطيني."
  },
  {
    id: 8,
    title: "مهندس ضمان جودة QA",
    company: "روابي للتكنولوجيا",
    location: "روابي",
    salary: "5500-7500 شيكل",
    type: "Full Time",
    match: 94,
    skills: ["Selenium", "Jira", "Automated Testing", "API Testing"],
    remote: "حضوري",
    description: "انضم إلى مركزنا التكنولوجي المتطور في مدينة روابي. ستكون مسؤولاً عن ضمان خلو برمجياتنا من العيوب وتقديم أفضل جودة."
  },
  {
    id: 9,
    title: "أخصائي موارد بشرية",
    company: "مجموعة استثمارية",
    location: "أريحا",
    salary: "4000-6000 شيكل",
    type: "Full Time",
    match: 81,
    skills: ["Recruitment", "Payroll", "Labor Law", "Communication"],
    remote: "حضوري",
    description: "إدارة رأس المال البشري هي قلب نجاحنا. نبحث عن أخصائي موارد بشرية للعمل في مكاتبنا في مدينة أريحا."
  },
  {
    id: 10,
    title: "مطور Backend Node.js",
    company: "حلول الدفع الإلكتروني",
    location: "طولكرم",
    salary: "6000-8500 شيكل",
    type: "Full Time",
    match: 90,
    skills: ["Node.js", "Express", "MongoDB", "Docker", "Microservices"],
    remote: "جزئياً عن بعد",
    description: "نعمل على ثورة في الدفع الإلكتروني في فلسطين. نحتاج إلى مطور باكيند لبناء خدمات قوية وقابلة للتوسع."
  },
  {
    id: 11,
    title: "محلل أمن سيبراني",
    company: "بنك وطني",
    location: "قلقيلية",
    salary: "8000-11000 شيكل",
    type: "Full Time",
    match: 95,
    skills: ["Cybersecurity", "Penetration Testing", "Security Audits", "SIEM"],
    remote: "حضوري",
    description: "الأمن المالي أولويتنا. نبحث عن صائد ثغرات ومحلل أمني لحماية بيانات البنك وعملائه."
  },
  {
    id: 12,
    title: "مدير مشاريع تقنية",
    company: "شركة استشارات",
    location: "رام الله",
    salary: "9000-13000 شيكل",
    type: "Full Time",
    match: 86,
    skills: ["Agile", "Scrum", "PMP", "Stakeholder Management"],
    remote: "هجين",
    description: "قيادة الفرق التقنية نحو النجاح تتطلب مهارات تواصل وإدارة عالية. انضم إلينا في رام الله لإدارة مشاريع وطنية كبرى."
  },
  {
    id: 13,
    title: "مطور تطبيقات موبايل",
    company: "فريق تطوير تطبيقات",
    location: "بيت لحم",
    salary: "5500-8000 شيكل",
    type: "Full Time",
    match: 89,
    skills: ["Flutter", "Dart", "Firebase", "State Management"],
    remote: "عن بعد",
    description: "نحن متخصصون في بناء تطبيقات الموبايل. نبحث عن مطور Flutter لإنشاء تطبيقات جذابة وسلسة لنظامي Android و iOS."
  },
  {
    id: 14,
    title: "مصمم جرافيك واجهات",
    company: "ستوديو تصميم",
    location: "غزة",
    salary: "3000-5000 شيكل",
    type: "Freelance",
    match: 83,
    skills: ["Photoshop", "Illustrator", "Branding", "UI Design"],
    remote: "عن بعد بالكامل",
    description: "نبحث عن مصمم جرافيك مستقل للمساعدة في مشاريع الهوية البصرية وتصميم الواجهات لعملائنا الدوليين."
  },
  {
    id: 15,
    title: "مندوب مبيعات حلول تقنية",
    company: "موزع برمجيات",
    location: "نابلس",
    salary: "4000-7000 شيكل",
    type: "Full Time",
    match: 75,
    skills: ["Sales", "Negotiation", "CRM", "Presentation Skills"],
    remote: "ميداني",
    description: "هل تملك مهارات الإقناع؟ انضم لفريق المبيعات لدينا لتسويق أحدث الحلول البرمجية للشركات في شمال الضفة."
  }
];

export const mockNotifications: Notification[] = [
  { id: 1, title: "تم قبول طلبك للمقابلة في شركة تكنولوجيا حديثة", time: "منذ ساعتين", isRead: false },
  { id: 2, title: "هناك 5 وظائف جديدة تطابق مهاراتك!", time: "منذ 5 ساعات", isRead: false },
  { id: 3, title: "تم التحقق من حسابك بنجاح ✓", time: "منذ يوم", isRead: true },
  { id: 4, title: "شركة ناشئة تقنية ترغب في عرض ملفك الشخصي", time: "منذ يومين", isRead: true },
  { id: 5, title: "نصيحة اليوم: أضف مهارات TypeScript لزيادة فرصك", time: "منذ 3 أيام", isRead: true },
];
